package com.example.lifefite;

public class ConfigChat {
    //En el codigo subido a github no ssale la api key ya que no me dejaba subirla porque se puede plagiar
    public static final String Api_Key = "sk-proj-iAj0fUWGpjL0EeF58VlbT3BlbkFJOOyILLqqsxBaq1fKjsgA";
}
